# otp-mvp

Minimal, working skeleton for the OTP auth gateway (Model A: gate sits in
front of the whole app, including its own login page). This is the MVP cut —
it implements the correct process separation (auth-web never touches key
material, otp-verifier does) but skips the container-hardening details from
the architecture doc (distroless base, seccomp, cap-drop, etc.). Get this
working end to end first, harden after.

## Layout

```
otp-mvp/
  otp-verifier/     C++ daemon, holds all key material, Unix socket only
  auth-web/         Node/Express: /login, /otp, /verify
  nginx/            snippets to drop into your existing app nginx configs
  keystore/devices/ per-device secret + active flag (git-ignored, real secrets)
  scripts/          provisioning + a dev-only code generator (no hardware yet)
  docker-compose.yml
```

## Quickstart

```bash
cd otp-mvp

# 1. provision a test device
./scripts/provision-device.sh
# -> prints a Device ID and a base64 secret

# 2. bring the stack up
docker compose up --build

# 3. generate the current code for that device (DEV ONLY — see the
#    warning in the script; this is a stand-in for the physical device
#    you haven't built yet)
node scripts/dev-gen-code.js <DEVICE_ID>

# 4. hit http://localhost:3000/login, enter the device ID + code
```

## Wiring into an existing app

1. Point `auth.example.com` at the `auth-web` container (see
   `nginx/auth-web.conf`).
2. In each app's existing nginx server block, `include` the pattern in
   `nginx/auth-gate.conf` — it adds an `auth_request` against `auth-web`'s
   `/verify` endpoint and redirects to the login page on 401. No changes to
   the app itself are required; it becomes unreachable until the gate
   clears, then behaves exactly as it always did.
3. Explicitly bypass the gate for anything that needs to stay reachable
   without a human present (health checks, webhooks) — see the comment at
   the bottom of `auth-gate.conf`.

## What's intentionally missing from this MVP

- Container hardening (distroless image, seccomp, `--cap-drop=ALL`,
  `--read-only`, disabled core dumps) — the Dockerfile here is a plain
  `debian-slim` build, not the locked-down target from the architecture doc.
- `/otp-recovery`.
- TLS termination — put this whole stack behind nginx with real certs; don't
  expose `auth-web`'s port 3000 directly in anything but local dev.
- Real device provisioning UX (etching the secret onto actual hardware).
- Alerting on repeated failed attempts.

## Socket protocol (auth-web ↔ otp-verifier)

Deliberately trivial for MVP — not JSON, no framing beyond a newline:

```
request:  "<DEVICE_ID> <CODE>\n"
response: "1\n"   (valid)
          "0\n"   (invalid — covers unknown device, wrong code, inactive device;
                   these are indistinguishable on purpose)
```
