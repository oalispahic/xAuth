// MVP OTP verifier daemon.
//
// Listens on a Unix domain socket. Protocol (intentionally trivial for MVP):
//   request:  "<device_id> <code>\n"
//   response: "1\n"  (valid)  or  "0\n"  (invalid)
//
// Never returns the generated code, only a boolean. Never logs the secret.
// device_id is validated against a fixed charset before it ever touches the
// filesystem, to rule out path traversal.
//
// Unknown device / inactive device / wrong code all take the same code path
// (dummy key, full HMAC computation still runs) so response timing doesn't
// leak which case occurred.

#include <openssl/evp.h>
#include <openssl/hmac.h>
#include <openssl/crypto.h> // CRYPTO_memcmp, OPENSSL_cleanse
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/stat.h>
#include <unistd.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <iostream>
#include <stdexcept>

static const char* KEYSTORE_ROOT = "/keystore/devices";
static const int STEP_SECONDS = 90;
static const int DIGITS = 8;

// ---- device_id validation ---------------------------------------------
// Crockford base32 alphabet, 6-8 chars. Reject anything else outright,
// before it's ever used to build a filesystem path.
bool valid_device_id(const std::string& id) {
    static const std::string alphabet = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
    if (id.size() < 6 || id.size() > 8) return false;
    for (char c : id) {
        if (alphabet.find(c) == std::string::npos) return false;
    }
    return true;
}

// ---- tiny base64 decoder -----------------------------------------------
std::vector<unsigned char> base64_decode(const std::string& in) {
    static const std::string chars =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::vector<int> T(256, -1);
    for (int i = 0; i < 64; i++) T[(unsigned char)chars[i]] = i;
    std::vector<unsigned char> out;
    int val = 0, bits = -8;
    for (unsigned char c : in) {
        if (c == '=' || T[c] == -1) continue;
        val = (val << 6) + T[c];
        bits += 6;
        if (bits >= 0) {
            out.push_back((val >> bits) & 0xFF);
            bits -= 8;
        }
    }
    return out;
}

// ---- keystore access -----------------------------------------------------
bool device_active(const std::string& device_id) {
    std::ifstream f(std::string(KEYSTORE_ROOT) + "/" + device_id + "/active");
    if (!f) return false;
    std::string v;
    f >> v;
    return v == "1";
}

// Loads the key for device_id into `key`. If the device is unknown, fills
// `key` with a fixed-length dummy instead, so the caller can still run a
// full HMAC pass and keep timing uniform.
bool load_key(const std::string& device_id, std::vector<unsigned char>& key) {
    std::ifstream f(std::string(KEYSTORE_ROOT) + "/" + device_id + "/secret");
    if (!f) {
        key.assign(32, 0);
        return false;
    }
    std::stringstream ss;
    ss << f.rdbuf();
    key = base64_decode(ss.str());
    if (key.empty()) key.assign(32, 0);
    return true;
}

// ---- OTP core (RFC 4226 dynamic truncation, same shape as the original
// generator, just factored so it can be called for counter-1/counter/counter+1)
std::vector<unsigned char> hmac_sha256(const std::vector<unsigned char>& key,
                                        const unsigned char* msg, size_t msg_len) {
    unsigned int len = EVP_MAX_MD_SIZE;
    std::vector<unsigned char> out(EVP_MAX_MD_SIZE);
    unsigned char* digest = HMAC(EVP_sha256(), key.data(), key.size(),
                                  msg, msg_len, out.data(), &len);
    if (!digest) throw std::runtime_error("HMAC failed");
    out.resize(len);
    return out;
}

uint32_t dynamic_truncate(const std::vector<unsigned char>& hmac, int digits) {
    int offset = hmac.back() & 0x0F;
    uint32_t bin_code = ((hmac[offset]     & 0x7F) << 24) |
                         ((hmac[offset + 1] & 0xFF) << 16) |
                         ((hmac[offset + 2] & 0xFF) << 8)  |
                          (hmac[offset + 3] & 0xFF);
    uint32_t mod = 1;
    for (int i = 0; i < digits; i++) mod *= 10;
    return bin_code % mod;
}

uint32_t code_for_counter(const std::vector<unsigned char>& key, uint64_t counter) {
    unsigned char counter_bytes[8];
    for (int i = 7; i >= 0; i--) {
        counter_bytes[i] = counter & 0xFF;
        counter >>= 8;
    }
    auto mac = hmac_sha256(key, counter_bytes, 8);
    return dynamic_truncate(mac, DIGITS);
}

// constant-time compare of a zero-padded numeric code against submitted input
bool codes_equal(uint32_t a, const char* submitted) {
    char buf[16];
    snprintf(buf, sizeof(buf), "%0*u", DIGITS, a);
    if (strlen(submitted) != (size_t)DIGITS) return false;
    return CRYPTO_memcmp(buf, submitted, DIGITS) == 0;
}

// ---- request handling ------------------------------------------------------
bool verify(const std::string& device_id, const char* submitted_code) {
    bool id_ok = valid_device_id(device_id);
    std::vector<unsigned char> key;
    bool has_key = id_ok && load_key(device_id, key);
    bool active = id_ok && has_key && device_active(device_id);
    if (key.empty()) key.assign(32, 0); // guard: keep HMAC path uniform either way

    time_t now = time(nullptr);
    uint64_t counter = (uint64_t)now / STEP_SECONDS;

    bool match = false;
    // Always do the HMAC work, even for unknown/inactive devices (dummy
    // key), so response timing doesn't leak which case it was.
    for (int64_t c = (int64_t)counter - 1; c <= (int64_t)counter + 1; c++) {
        uint32_t code = code_for_counter(key, (uint64_t)c);
        if (codes_equal(code, submitted_code)) match = true;
    }

    OPENSSL_cleanse(key.data(), key.size());
    return match && active;
}

// ---- socket server -----------------------------------------------------------
int main(int argc, char** argv) {
    const char* sock_path = argc > 1 ? argv[1] : "/sockets/otp-verifier.sock";
    unlink(sock_path);

    int srv = socket(AF_UNIX, SOCK_STREAM, 0);
    if (srv < 0) { perror("socket"); return 1; }

    sockaddr_un addr{};
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, sock_path, sizeof(addr.sun_path) - 1);

    if (bind(srv, (sockaddr*)&addr, sizeof(addr)) < 0) { perror("bind"); return 1; }
    chmod(sock_path, 0660); // only auth-web's uid/group should reach this
    if (listen(srv, 16) < 0) { perror("listen"); return 1; }

    std::cerr << "otp-verifier listening on " << sock_path << std::endl;

    while (true) {
        int client = accept(srv, nullptr, nullptr);
        if (client < 0) continue;

        char buf[256] = {0};
        ssize_t n = read(client, buf, sizeof(buf) - 1);
        if (n > 0) {
            char device_id[16] = {0};
            char code[16] = {0};
            if (sscanf(buf, "%15s %15s", device_id, code) == 2) {
                bool ok = verify(device_id, code);
                const char* resp = ok ? "1\n" : "0\n";
                write(client, resp, strlen(resp));
            } else {
                write(client, "0\n", 2);
            }
        }
        close(client);
    }
    return 0;
}
