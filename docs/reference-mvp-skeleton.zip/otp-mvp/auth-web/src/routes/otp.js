import { Router } from "express";
import { verifyCode } from "../lib/verifierClient.js";
import { takeAttempt } from "../lib/rateLimit.js";
import { createSession, setSessionCookie } from "../lib/session.js";

const router = Router();
const DEVICE_ID_RE = /^[0-9A-HJKMNP-TV-Z]{6,8}$/; // Crockford base32
const CODE_RE = /^[0-9]{8}$/;

router.post("/otp", async (req, res) => {
  const deviceId = String(req.body.device_id || "").toUpperCase();
  const code = String(req.body.code || "");
  const redirectTo = isSafeRedirect(req.body.redirect) ? req.body.redirect : "/";

  if (!DEVICE_ID_RE.test(deviceId) || !CODE_RE.test(code)) {
    return fail(res, redirectTo);
  }

  const allowed = await takeAttempt(deviceId);
  if (!allowed) {
    return fail(res, redirectTo);
  }

  let valid = false;
  try {
    valid = await verifyCode(deviceId, code);
  } catch (err) {
    console.error("verifier call failed:", err.message);
    return fail(res, redirectTo);
  }

  if (!valid) {
    return fail(res, redirectTo);
  }

  const sessionId = await createSession(deviceId);
  setSessionCookie(res, sessionId);
  res.redirect(302, redirectTo);
});

function fail(res, redirectTo) {
  // Same response shape regardless of *why* it failed (unknown id, wrong
  // code, inactive device, rate-limited) — don't give an attacker a signal.
  res.status(401).type("html").send(
    `<p>Invalid code.</p><a href="/login?redirect=${encodeURIComponent(redirectTo)}">Try again</a>`
  );
}

function isSafeRedirect(path) {
  // Only allow same-origin relative paths — never redirect to an
  // attacker-supplied absolute/external URL.
  return typeof path === "string" && path.startsWith("/") && !path.startsWith("//");
}

export default router;
