import { Router } from "express";
import { sessionValid, COOKIE_NAME } from "../lib/session.js";

const router = Router();

// Called by nginx's auth_request directive on every request to a gated app.
router.get("/verify", async (req, res) => {
  const sessionId = req.cookies[COOKIE_NAME];
  const valid = await sessionValid(sessionId);
  res.sendStatus(valid ? 200 : 401);
});

export default router;
