import { Router } from "express";

const router = Router();

router.get("/login", (req, res) => {
  const redirectTo = typeof req.query.redirect === "string" ? req.query.redirect : "/";
  res.type("html").send(`<!doctype html>
<html>
<head><meta charset="utf-8"><title>Auth</title></head>
<body>
  <form method="POST" action="/otp">
    <input type="hidden" name="redirect" value="${escapeHtml(redirectTo)}">
    <label>Device ID <input name="device_id" autocomplete="off" required></label><br>
    <label>Code <input name="code" inputmode="numeric" pattern="[0-9]{8}" autocomplete="off" required></label><br>
    <button type="submit">Verify</button>
  </form>
</body>
</html>`);
});

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  })[c]);
}

export default router;
