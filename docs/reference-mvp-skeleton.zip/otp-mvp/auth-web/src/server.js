import express from "express";
import cookieParser from "cookie-parser";
import loginRoute from "./routes/login.js";
import otpRoute from "./routes/otp.js";
import verifyRoute from "./routes/verify.js";

const app = express();
app.use(cookieParser());
app.use(express.urlencoded({ extended: false }));

app.use(loginRoute);
app.use(otpRoute);
app.use(verifyRoute);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`auth-web listening on :${PORT}`));
