#!/usr/bin/env bash
# Generates a new device: a Crockford base32 ID + a CSPRNG secret, writes
# it into the keystore. The printed secret is what eventually gets loaded
# onto the physical keychain — for now, keep it for local testing.
set -euo pipefail

ALPHABET="0123456789ABCDEFGHJKMNPQRSTVWXYZ"
ID_LEN=8
KEYSTORE_DIR="${KEYSTORE_DIR:-./keystore/devices}"

gen_id() {
  local id=""
  for _ in $(seq 1 "$ID_LEN"); do
    id+="${ALPHABET:$((RANDOM % ${#ALPHABET})):1}"
  done
  echo "$id"
}

DEVICE_ID="$(gen_id)"
SECRET_B64="$(openssl rand -base64 32)"

DIR="$KEYSTORE_DIR/$DEVICE_ID"
mkdir -p "$DIR"
printf '%s' "$SECRET_B64" > "$DIR/secret"
printf '1' > "$DIR/active"
chmod 700 "$DIR"
chmod 400 "$DIR/secret"

echo "Device ID: $DEVICE_ID"
echo "Secret (base64, load onto the physical device): $SECRET_B64"
