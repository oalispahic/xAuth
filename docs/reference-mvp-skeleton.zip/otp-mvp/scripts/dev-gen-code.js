#!/usr/bin/env node
// DEV/TEST ONLY.
//
// Computes the current code for a device by reading its keystore secret
// directly. This defeats the entire point of keeping the secret only
// inside otp-verifier — it exists purely so you can test the login flow
// before you have physical hardware that generates codes on its own.
// Never run this anywhere near anything resembling production.
import fs from "node:fs";
import crypto from "node:crypto";

const deviceId = process.argv[2];
if (!deviceId) {
  console.error("usage: dev-gen-code.js <DEVICE_ID>");
  process.exit(1);
}

const STEP_SECONDS = 90;
const DIGITS = 8;

const secretB64 = fs
  .readFileSync(`./keystore/devices/${deviceId}/secret`, "utf8")
  .trim();
const key = Buffer.from(secretB64, "base64");

const counter = Math.floor(Date.now() / 1000 / STEP_SECONDS);
const counterBuf = Buffer.alloc(8);
counterBuf.writeBigUInt64BE(BigInt(counter));

const hmac = crypto.createHmac("sha256", key).update(counterBuf).digest();
const offset = hmac[hmac.length - 1] & 0x0f;
const binCode =
  ((hmac[offset] & 0x7f) << 24) |
  ((hmac[offset + 1] & 0xff) << 16) |
  ((hmac[offset + 2] & 0xff) << 8) |
  (hmac[offset + 3] & 0xff);

const mod = 10 ** DIGITS;
const code = (binCode % mod).toString().padStart(DIGITS, "0");
console.log(code);
